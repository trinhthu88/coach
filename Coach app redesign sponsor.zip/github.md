repo: trinhthu88/coach
branch: main

## Last sync
date: 2026-09-13T09:20:00Z

### Updated in this project
- Built `Clariva Sponsor Prototype.dc.html` — sponsor dashboard, cohort detail and full leader page, grounded in `src/pages/sponsor/`.
- Kept the real privacy rule from `useSponsorDashboardData.ts`: the org dashboard is aggregate-only, leader names appear only inside an unsuppressed cohort.
- Leader detail promoted from the drawer (`SponsorLeaderDrawer.tsx`) to a full page: week-by-week timeline, pace vs. plan, quiz scores, session attendance.
- Per-week engagement (`SponsorProgrammeEngagementRow`) rendered as grouped bars per week instead of the `ProgrammeEngagementTable` grid; locked weeks dimmed with unlock dates.
- Sponsor action is "Flag to Clariva team" only, matching the `admin_alerts` insert in `SponsorDashboard.tsx` — no direct leader contact.
- Two discarded dashboard direction drafts kept as `Sponsor Dashboard A.dc.html` / `Sponsor Dashboard B.dc.html` (B was chosen).

## Sync history
### 2026-09-07
- Programme progress card on the participant dashboard now mirrors `ProgrammeProgressCard.tsx`: stats renamed to Skills completed / Reflection streak / Quiz average / Triad sessions, plus the new per-week "Quiz scores" pill row.
- Daily prompt card (dashboard nudge + component screen) rebuilt to match `DailyPromptCard.tsx`: confidence slider removed, reflection textarea + "Done", answered state reads "Thanks — logged for today."
- Nudge eyebrow copy aligned to `training.json`.

### 2026-08-16
- Built `Clariva Onboarding.dc.html` — graphic-led pre-app intro plus in-app pointers for coachee, coach and sponsor.
- Rebuilt the onboarding backdrop as the real app shell from `src/components/AppLayout.tsx`.

### 2026-08-11
- Built `Clariva Sponsor.dc.html` — sponsor dashboard, multi-cohort view, first-login state, report export, roster drawer.

### 2026-08-07
- Built `Clariva Prototype.dc.html` — clickable redesign of the coachee / coach / admin roles.
- Lifted design tokens from `src/index.css` (Sky #3db4d0, Navy #062f3e, Amber #e8874a, Paper #f6f3ee; Montserrat + Fraunces).

## Screen map
| Prototype screen | Built from |
| --- | --- |
| Sponsor prototype — dashboard | src/pages/sponsor/SponsorDashboard.tsx, src/hooks/sponsor/useSponsorDashboardData.ts, src/pages/sponsor/sponsorUtils.ts |
| Sponsor prototype — cohort detail | src/pages/sponsor/SponsorCohortDetail.tsx, src/hooks/sponsor/useSponsorCohortData.ts, src/pages/sponsor/_shared.tsx |
| Sponsor prototype — leader page | src/pages/sponsor/SponsorLeaderDrawer.tsx, src/hooks/sponsor/useSponsorDashboardData.ts |
| Sponsor prototype — engagement chart | src/pages/sponsor/_shared.tsx (ProgrammeEngagementTable), src/hooks/admin/useAdminProgrammeEngagement.ts |
| Sponsor prototype — flag to Clariva team | src/pages/sponsor/SponsorDashboard.tsx (admin_alerts insert) |
| App shell (rail, header, role switch) | src/components/AppLayout.tsx |
| Dashboard (Directions A & B) | src/pages/Dashboard.tsx, src/pages/dashboard/DashboardStatsBar.tsx, src/pages/dashboard/cards/ |
| Find coaches / coach detail | src/pages/Coaches.tsx, src/pages/CoachDetail.tsx |
| Book a session | src/pages/BookSession.tsx, src/pages/CoachAvailability.tsx |
| Sessions + session detail | src/pages/Sessions.tsx, src/pages/SessionDetail.tsx |
| My journey | src/pages/CoacheeJourney.tsx |
| My clients | src/pages/CoachClients.tsx |
| Admin overview | src/pages/admin/AdminDashboard.tsx |
| Sponsor dashboard / cohorts / report / drawer (v1) | src/pages/admin/_shared.tsx, src/pages/admin/AdminCohorts.tsx, src/pages/admin/AdminAnalytics.tsx |
| Onboarding — app shell / role backdrops | src/components/AppLayout.tsx, src/pages/Dashboard.tsx, src/pages/dashboard/cards/ |
| Programme screens — participant dashboard + progress card | src/components/ProgrammeProgressCard.tsx, src/hooks/dashboard/useProgrammeProgress.ts |
| Programme screens — training journey | src/pages/TrainingWeeks.tsx, src/hooks/training/useTrainingWeeks.ts |
| Programme screens — skill card | src/pages/SkillCardView.tsx, src/components/training/ThisWeekSkillCard.tsx |
| Programme screens — quiz | src/pages/QuizView.tsx, src/hooks/training/useQuiz.ts |
| Programme screens — triad reflection | src/pages/ReflectionView.tsx, src/pages/triads/TriadReflectionPage.tsx |
| Programme screens — module config | src/pages/admin/AdminProgrammes.tsx, src/pages/admin/AdminTrainingContent.tsx |
| Programme screens — triad assignment | src/pages/admin/AdminTriads.tsx, src/hooks/triads/useAdminTriads.ts |
| Programme screens — daily prompt card | src/components/training/DailyPromptCard.tsx, src/locales/en/training.json |
| Programme screens — notification bell | src/components/NotificationBell.tsx, src/hooks/useNotifications.ts |
