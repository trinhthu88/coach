repo: trinhthu88/coach
branch: main

## Last sync
date: 2026-08-16T10:00:36Z

### Updated in this project
- Built `Clariva Onboarding.dc.html` — graphic-led pre-app intro (5–6 steps) plus in-app pointers for coachee, coach and sponsor.
- Rebuilt the onboarding backdrop as the real app shell: grouped nav per role, icons, active-item bar, sidebar footer, 68px header from `src/components/AppLayout.tsx`; coachee dashboard content (greeting, next-session hero, 4 stat cards, session log / action items) from `src/pages/dashboard/CoacheeDashboardView.tsx` and the coach dashboard (stat labels, booking requests, upcoming sessions) from `src/pages/dashboard/CoachDashboardView.tsx`.

## Sync history
### 2026-08-11
- Built `Clariva Sponsor.dc.html` — new Program Sponsor (HR/L&D) experience: dashboard, multi-cohort view, first-login state, report export, roster detail drawer.
- Reused real tokens from `src/index.css` and admin layout conventions from `src/pages/admin/_shared.tsx` (Kpi, Pill, MiniBar) + `AdminCohorts.tsx`.

### 2026-08-07
- Built `Clariva Prototype.dc.html` — clickable redesign of the Clariva coaching app (coachee / coach / admin roles).
- Lifted the real design tokens from `src/index.css` (Sky #3db4d0, Navy #062f3e, Amber #e8874a, Paper #f6f3ee; Montserrat + Fraunces).
- Copied brand logos into `src/assets/`.

## Screen map
| Prototype screen | Built from |
| --- | --- |
| App shell (rail, header, role switch) | src/components/AppLayout.tsx |
| Dashboard (Directions A & B) | src/pages/Dashboard.tsx |
| Find coaches | src/pages/Coaches.tsx |
| Coach detail | src/pages/CoachDetail.tsx |
| Book a session | src/pages/BookSession.tsx, src/pages/CoachAvailability.tsx |
| Sessions + session detail | src/pages/Sessions.tsx, src/pages/SessionDetail.tsx |
| My journey | src/pages/CoacheeJourney.tsx |
| My clients | src/pages/CoachClients.tsx |
| Admin overview | src/pages/admin/AdminDashboard.tsx |
| Sponsor dashboard / cohorts / report / drawer | src/index.css, src/pages/admin/_shared.tsx, src/pages/admin/AdminCohorts.tsx, src/pages/admin/AdminAnalytics.tsx |
| Onboarding — app shell backdrop (rail, groups, header) | src/components/AppLayout.tsx |
| Onboarding — coachee dashboard backdrop | src/pages/dashboard/CoacheeDashboardView.tsx |
| Onboarding — coach dashboard backdrop | src/pages/dashboard/CoachDashboardView.tsx, src/pages/Dashboard.tsx |
| Onboarding — sponsor dashboard backdrop | src/pages/admin/_shared.tsx, Clariva Sponsor.dc.html |
